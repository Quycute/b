# condi v5
zxcr9999's skidded source. i laughed a lot reading this skid work. meowy christmas zxcr!!!
## zxcr9999's work:
- take the customer botnet that hamlog sold
- remove selfrep
- skid antarctic tcpnull, syndata
- skid momentum's nudp, stdhex
- change the cnc
- make a method named tcplegit thats just ack
- sell all this shit for $100
- gets leaked after first sale
### Info
I leaked this for educational purposes only.
